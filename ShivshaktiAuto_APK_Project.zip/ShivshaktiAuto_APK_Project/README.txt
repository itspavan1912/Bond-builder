SHIVSHAKTI AUTO — Android APK project (offline)

The website is bundled inside app/src/main/assets/index.html. The app does not need internet to display the inventory. It uses WebView localStorage for data, so keep app data intact and use the website's backup feature regularly.

BUILD APK USING YOUR PHONE (GitHub Actions):
1. Extract this ZIP on your phone.
2. Open github.com in Chrome and sign in/create an account.
3. Create a new repository named ShivshaktiAuto.
4. Upload all files AND folders from the extracted project to the repository root (including the .github/workflows/build-apk.yml file; enable “show hidden files” if needed).
5. Open the repository's Actions tab and select “Build SHIVSHAKTI AUTO APK”. Tap “Run workflow”.
6. When the workflow finishes with a green check, open that run and download the artifact named SHIVSHAKTI-AUTO-APK.
7. Extract the downloaded artifact ZIP; install app-debug.apk. Android may ask to allow installation from your browser/files app.

No Android Studio needed. GitHub account/network is needed to build; after installed, the app's bundled website works offline.
